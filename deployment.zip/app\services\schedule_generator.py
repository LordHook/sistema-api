"""
Algoritmo de Generación de Horarios (Rol de Servicio)

Reglas:
- Máximo 7 días consecutivos de trabajo
- 1 día de descanso por semana
- Descanso rotativo: avanza +1 día cada semana (+8 días desde el último descanso)
- Al pasar Domingo→Lunes: 2 días consecutivos de descanso
- Distribución equitativa: ~N/7 personas descansando por día
- Bloqueo por renuncia: si fecha >= resignation_date → 'R'
"""
import calendar
from datetime import date, timedelta
from app.extensions import db
from app.models.schedule import ScheduleEntry
from app.models.worker import Worker


def generate_monthly_schedule(year, month):
    """Genera el rol de servicio completo para un mes dado (todo el personal)."""
    num_days = calendar.monthrange(year, month)[1]

    # Limpiar entradas auto-generadas previas del mes
    ScheduleEntry.query.filter_by(
        year=year, month=month, is_auto_generated=True
    ).delete()
    db.session.flush()

    all_workers = _get_relevant_workers(year, month)

    # Group workers by section
    sections = {'A': [], 'B': [], 'C': [], 'D': []}
    for w in all_workers:
        if w.section in sections:
            sections[w.section].append(w)

    entries = []

    # Sections A, B, C (fixed shift)
    for section_key in ['A', 'B', 'C']:
        entries.extend(
            _generate_fixed_shift_section(sections[section_key], year, month, num_days, 'M')
        )

    # Section D (rotating shifts by group)
    entries.extend(_generate_section_d(sections['D'], year, month, num_days))

    db.session.add_all(entries)
    db.session.commit()
    return len(entries)


def generate_group_schedule(year, month, group_number):
    """Genera el horario exclusivamente para un grupo operativo específico (1, 2 o 3).
    La distribución equitativa de descansos se calcula solo con los integrantes de ese grupo.
    """
    num_days = calendar.monthrange(year, month)[1]

    all_workers = _get_relevant_workers(year, month)
    group_workers = [w for w in all_workers if w.section == 'D' and (w.group_number or 1) == group_number]

    if not group_workers:
        return 0

    # Delete only this group's auto-generated entries
    worker_ids = [w.id for w in group_workers]
    ScheduleEntry.query.filter(
        ScheduleEntry.worker_id.in_(worker_ids),
        ScheduleEntry.year == year,
        ScheduleEntry.month == month,
        ScheduleEntry.is_auto_generated == True,  # noqa: E712
    ).delete(synchronize_session='fetch')
    db.session.flush()

    # Generate only for this group
    shift_rotation = ['M', 'T', 'N']
    base_shift_index = (group_number - 1) % 3

    entries = _generate_rotating_section(
        group_workers, year, month, num_days,
        shift_rotation, base_shift_index
    )

    db.session.add_all(entries)
    db.session.commit()
    return len(entries)


def _get_relevant_workers(year, month):
    """Get active workers, those who resigned during this month, and filtering by start_date."""
    workers = Worker.query.filter_by(status='activo').order_by(Worker.order_number).all()
    resigned_this_month = Worker.query.filter(
        Worker.status == 'inactivo',
        Worker.resignation_date != None,  # noqa: E711
        db.extract('year', Worker.resignation_date) == year,
        db.extract('month', Worker.resignation_date) == month,
    ).order_by(Worker.order_number).all()

    # Combinar
    all_workers = workers + [w for w in resigned_this_month if w not in workers]
    
    # Filtrar ingresos futuros: si la start_date es de un mes futuro, no listarlo
    filtered_workers = []
    for w in all_workers:
        if w.start_date:
            if w.start_date.year > year or (w.start_date.year == year and w.start_date.month > month):
                continue # No ha ingresado en este mes ni antes
        filtered_workers.append(w)
        
    return filtered_workers


def _generate_section_d(d_workers, year, month, num_days):
    """Generate rotating shifts for Section D organized by groups."""
    entries = []
    groups = {}
    for w in d_workers:
        g = w.group_number or 1
        if g not in groups:
            groups[g] = []
        groups[g].append(w)

    shift_rotation = ['M', 'T', 'N']
    for group_num in sorted(groups.keys()):
        group_workers = groups[group_num]
        base_shift_index = (group_num - 1) % 3
        entries.extend(
            _generate_rotating_section(
                group_workers, year, month, num_days,
                shift_rotation, base_shift_index
            )
        )
    return entries


def _generate_fixed_shift_section(workers, year, month, num_days, default_shift):
    """Secciones A/B/C: turno fijo. Sección A rige sus descansos fijos."""
    entries = []
    
    # Separar Sección A de B y C
    sec_a = [w for w in workers if w.section == 'A']
    sec_others = [w for w in workers if w.section != 'A']
    
    if sec_a:
        entries.extend(_generate_sequential_schedule(sec_a, year, month, num_days, [default_shift], 0, is_fixed=True, section_a_rules=True))
    
    if sec_others:
        entries.extend(_generate_sequential_schedule(sec_others, year, month, num_days, [default_shift], 0, is_fixed=True, section_a_rules=False))
        
    return entries


def _generate_rotating_section(workers, year, month, num_days, shift_rotation, base_shift_index):
    """Sección D: turnos rotativos M→T→N con descansos escalonados."""
    return _generate_sequential_schedule(workers, year, month, num_days, shift_rotation, base_shift_index, is_fixed=False)


def _generate_sequential_schedule(workers, year, month, num_days, shift_rotation, base_shift_index, is_fixed=False, section_a_rules=False):
    """
    Generates deterministic staggered schedule across months using DB history.
    If section_a_rules is True, ignores staggered history and STRICTLY assigns 'M' on Mon-Fri and 'D' on Sat-Sun.
    """
    entries = []

    for idx, worker in enumerate(workers):
        # 1. Determine anchor state from previous days (skip for Sec A)
        last_date_checked = date(year, month, 1) - timedelta(days=1)
        prev_entries = []
        if not section_a_rules:
            prev_entries = ScheduleEntry.query.filter(
                ScheduleEntry.worker_id == worker.id,
                db.func.date(db.cast(ScheduleEntry.year, db.String) + '-' + 
                             db.func.lpad(db.cast(ScheduleEntry.month, db.String), 2, '0') + '-' + 
                             db.func.lpad(db.cast(ScheduleEntry.day, db.String), 2, '0')) <= last_date_checked
            ).order_by(
                ScheduleEntry.year.desc(), 
                ScheduleEntry.month.desc(), 
                ScheduleEntry.day.desc()
            ).limit(14).all()

        last_rest_date = None
        current_shift_index = base_shift_index
        pending_extra_rest = False

        if prev_entries:
            work_shifts = [e.shift_code for e in prev_entries if e.shift_code in shift_rotation]
            if work_shifts:
                most_recent_shift = work_shifts[0]
                if most_recent_shift in shift_rotation:
                    current_shift_index = shift_rotation.index(most_recent_shift)
            
            # Check the last rest
            if prev_entries[0].shift_code == 'D' and date(prev_entries[0].year, prev_entries[0].month, prev_entries[0].day).weekday() == 6:
                pending_extra_rest = True
                # Logical anchor was before Sunday, pretend anchor was an invisible start
                last_rest_date = date(prev_entries[0].year, prev_entries[0].month, prev_entries[0].day) - timedelta(days=8)
            else:
                for e in prev_entries:
                    if e.shift_code == 'D':
                        last_rest_date = date(e.year, e.month, e.day)
                        break

        # If no previous entries, fake an initial anchor date based on their order
        if not last_rest_date:
            rest_day_start = (idx % 7) + 1
            last_rest_date = date(year, month, 1) - timedelta(days = 8 - rest_day_start)
            
        # 2. Sequence through the month
        for day in range(1, num_days + 1):
            current_date = date(year, month, day)

            # Check if this is a manually set entry (vacation, compensated)
            existing = ScheduleEntry.query.filter_by(
                worker_id=worker.id, year=year, month=month, day=day, is_auto_generated=False
            ).first()
            if existing: # do not touch manual entries
                continue

            # Check start_date mid-month entry
            if worker.start_date and current_date < worker.start_date:
                entries.append(ScheduleEntry(
                    worker_id=worker.id, year=year, month=month, day=day,
                    shift_code='NI', is_auto_generated=True
                ))
                continue

            # Check resignation
            if worker.resignation_date and current_date >= worker.resignation_date:
                entries.append(ScheduleEntry(
                    worker_id=worker.id, year=year, month=month, day=day,
                    shift_code='R', is_auto_generated=True
                ))
                continue

            # Process state machine
            if section_a_rules:
                if current_date.weekday() >= 5: # 5=Sat, 6=Sun
                    shift = 'D'
                else:
                    shift = shift_rotation[0] # Default shift (typically 'M')
            elif pending_extra_rest:
                # Give Monday as requested
                shift = 'D'
                pending_extra_rest = False
                last_rest_date = current_date
                if not is_fixed:
                    current_shift_index = (current_shift_index + 1) % len(shift_rotation)
            else:
                days_since_rest = (current_date - last_rest_date).days
                if days_since_rest >= 8: # Hit next rest day
                    shift = 'D'
                    if current_date.weekday() == 6: # Sunday
                        pending_extra_rest = True
                    else:
                        last_rest_date = current_date
                        if not is_fixed:
                            current_shift_index = (current_shift_index + 1) % len(shift_rotation)
                else:
                    shift = shift_rotation[current_shift_index] if not is_fixed else shift_rotation[0]

            entries.append(ScheduleEntry(
                worker_id=worker.id, year=year, month=month, day=day,
                shift_code=shift, is_auto_generated=True
            ))

    return entries


def get_schedule_grid(year, month, group_filter=None, user_role='admin'):
    """Returns the schedule data structured for the grid view.
    group_filter: 'all', 'staff', '1', '2', '3', or None
    user_role: 'admin', 'supervisor', etc to apply visibility rules.
    """
    num_days = calendar.monthrange(year, month)[1]

    workers = Worker.query.order_by(Worker.section, Worker.group_number,
                                     Worker.order_number).all()

    # Filter to relevant workers
    relevant_workers = []
    for w in workers:
        if w.status == 'activo':
            relevant_workers.append(w)
        elif w.resignation_date:
            if w.resignation_date.year == year and w.resignation_date.month >= month:
                relevant_workers.append(w)
            elif w.resignation_date.year > year:
                relevant_workers.append(w)

    # Apply group filter
    if group_filter and group_filter != 'all':
        if group_filter == 'staff':
            relevant_workers = [w for w in relevant_workers if w.section in ('A', 'B', 'C')]
        elif group_filter.isdigit():
            gnum = int(group_filter)
            relevant_workers = [w for w in relevant_workers
                                if (w.section == 'D' and (w.group_number or 1) == gnum) or w.section == 'B']

    # Security Rules: Hide Section A from Supervisors
    if user_role == 'supervisor':
        relevant_workers = [w for w in relevant_workers if w.section != 'A']

    entries = ScheduleEntry.query.filter_by(year=year, month=month).all()
    entry_map = {}
    for e in entries:
        entry_map[(e.worker_id, e.day)] = e

    sections = _build_sections(relevant_workers, entry_map, num_days, group_filter)

    day_headers = []
    for d in range(1, num_days + 1):
        dt = date(year, month, d)
        day_headers.append({
            'day': d,
            'weekday': ['Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa', 'Do'][dt.weekday()],
            'is_weekend': dt.weekday() >= 5,
        })

    return {
        'year': year,
        'month': month,
        'month_name': [
            '', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
            'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
        ][month],
        'num_days': num_days,
        'day_headers': day_headers,
        'sections': sections,
        'group_filter': group_filter,
    }


def _build_sections(workers, entry_map, num_days, group_filter=None):
    """Organizes workers into display sections."""
    sections = []

    # If filtering by a specific group, only show section D and section B
    if group_filter and group_filter.isdigit():
        gnum = int(group_filter)
        
        # Sec B
        sec_b = [w for w in workers if w.section == 'B']
        if sec_b:
            sections.append({
                'key': 'B',
                'name': 'Área de Gestión de Video',
                'groups': [_build_worker_rows(sec_b, entry_map, num_days)],
            })

        # Sec D
        d_workers = [w for w in workers if w.section == 'D']
        if d_workers:
            groups_data = {'CCO': [], 'SCV': []}
            for w in d_workers:
                area_key = w.area if w.area in ('CCO', 'SCV') else 'CCO'
                groups_data[area_key].append(w)

            d_groups = []
            for area in ['CCO', 'SCV']:
                area_workers = groups_data.get(area, [])
                if area_workers:
                    d_groups.append({
                        'label': f'Grupo {gnum} - {area}',
                        'rows': _build_worker_rows(area_workers, entry_map, num_days)['rows'],
                    })

            if d_groups:
                total_in_group = sum(len(g['rows']) for g in d_groups)
                sections.append({
                    'key': 'D',
                    'name': f'Grupo {gnum} — Rol de Servicio Operativo ({total_in_group} integrantes, ~{total_in_group // 7 or 1} descansos/día)',
                    'groups': d_groups,
                })
        return sections

    # Normal view (all or staff)
    section_config = [
        ('A', 'Jefatura CCO, Planta Externa, Encargados y Coordinadores', None),
        ('B', 'Área de Gestión de Video', None),
        ('C', 'Supervisores', None),
    ]

    for sec_key, sec_name, _ in section_config:
        sec_workers = [w for w in workers if w.section == sec_key]
        if sec_workers:
            sections.append({
                'key': sec_key,
                'name': sec_name,
                'groups': [_build_worker_rows(sec_workers, entry_map, num_days)],
            })

    # Section D - show if 'all' or no filter
    if not group_filter or group_filter == 'all':
        d_workers = [w for w in workers if w.section == 'D']
        if d_workers:
            groups_data = {}
            for w in d_workers:
                g = w.group_number or 1
                if g not in groups_data:
                    groups_data[g] = {'CCO': [], 'SCV': []}
                area_key = w.area if w.area in ('CCO', 'SCV') else 'CCO'
                groups_data[g][area_key].append(w)

            d_groups = []
            for group_num in sorted(groups_data.keys()):
                for area in ['CCO', 'SCV']:
                    area_workers = groups_data[group_num].get(area, [])
                    if area_workers:
                        d_groups.append({
                            'label': f'Grupo {group_num} - {area}',
                            'rows': _build_worker_rows(area_workers, entry_map, num_days)['rows'],
                        })

            if d_groups:
                sections.append({
                    'key': 'D',
                    'name': 'Rol de Servicio Operativo',
                    'groups': d_groups,
                })

    return sections


def _build_worker_rows(workers, entry_map, num_days):
    """Builds row data for a list of workers."""
    rows = []
    for w in workers:
        days = []
        for d in range(1, num_days + 1):
            entry = entry_map.get((w.id, d))
            shift = entry.shift_code if entry else ''
            entry_id = entry.id if entry else None
            days.append({
                'day': d,
                'shift': shift,
                'entry_id': entry_id,
                'color': ScheduleEntry.SHIFT_COLORS.get(shift, '#374151'),
            })
        rows.append({
            'worker': {
                'id': w.id,
                'order_number': w.order_number,
                'name': w.full_name,
                'regime': w.regime,
                'area': w.area,
                'status': w.status,
            },
            'days': days,
        })
    return {'rows': rows}

